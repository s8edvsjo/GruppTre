Component folder
- All components created in the builder are placed in this directory.