Image folder
- All images created in the builder are placed in this directory.